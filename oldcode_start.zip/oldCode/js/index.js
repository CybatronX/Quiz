$('.heroImage').attr('src', start.heroImageURL);
$('.quizForm').attr('action', start.quizURL);

function GetURLParameter(sParam) {
  var sPageURL = window.location.search.substring(1);
  var sURLVariables = sPageURL.split('&');
  for (var i = 0; i < sURLVariables.length; i++) {
    var sParameterName = sURLVariables[i].split('=');
    if (sParameterName[0] == sParam) {
      return sParameterName[1];
    }
  }
};

var currentAnswerKey = GetURLParameter('wpvqresults');

$("input[name='custom_wpvqresults']").val(currentAnswerKey);