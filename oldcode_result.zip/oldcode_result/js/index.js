var quizOutputs = [
		{
		param: "crownChakra ",
		header: "<p>Your strongest chakra is the <strong>Crown Chakra</strong>, representing the ability to be fully connected spiritually.</p>",
		content:"<p>The Crown Chakra is the source of spirituality, understanding, and enlightenment. You feel your place in the great expanse of this universe, and the role of your own life journey within it.</p><p>You feel a sense of harmony and unity in this world, and you find yourself uncontrollably compelled to feel a part of it. Something within you causes you to know and feel that there is a meaning and pattern to all of existence, and you feel most at peace when you are at one with that understanding. You are humbled by the vastness of reality, and your sense of self is unencumbered by the human ego. You work to create meaning and significance in your life, not for yourself but for the greater good.</p>",
		image:"http://66.media.tumblr.com/tumblr_lo7i4ubT4f1qkmpj8o1_500.gif",
		},
		{
		param: "thirdEyeChakra",
		header: "<p>Your strongest chakra is the Third Eye Chakra.</span></p>",
		content:"<p>The Third Eye Chakra is the second of the 3 spiritual chakras, and it is what gives you the ability to see what is inside and outside of yourself and others.</p><p>You possess a gateway which connects what is internal and external. You are able to internalize important and meaningful lessons, and translate your emotions and inner truths into action and being. This is the reason why your intuition is so strong, and why you are able to predict long-term outcomes for your actions. The energy of this chakra is what enables you to visualize your spiritual and physical goals on your life journey, and access your inner guidance from the depths of your being. You are incredibly observant and mindful of your surroundings, and often notice the little details that others miss.</p>",
		image:"http://66.media.tumblr.com/tumblr_lo7i4ubT4f1qkmpj8o1_500.gif",
		},
		{
		param: "throatChakra",
		header: "Your Score was 2/10",
		content:"You can definitely do better! It is time to read the books again!",
		image:"http://66.media.tumblr.com/tumblr_lo7i4ubT4f1qkmpj8o1_500.gif",
		},
		{
		param: "heartChakra",
		header: "Your Score was 3/10",
		content:"You can definitely do better! It is time to read the books again!",
		image:"http://66.media.tumblr.com/tumblr_lo7i4ubT4f1qkmpj8o1_500.gif",
		},
		{
		param: "solarPlexusChakra",
		header: "Your Score was 4/10",
		content:"You did okay, but you can definitely do better! It might be time to read the books again!",
		image:"http://i.giphy.com/cYYx0b3DcYwOA.gif",
		},
		{
		param: "sacralChakra",
		header: "Your Score was 5/10",
		content:"You did okay, but you can definitely do better! It might be time to read the books again!",
		image:"http://i.giphy.com/cYYx0b3DcYwOA.gif",
		},
		{
		param: "rootChakra",
		header: "Your Score was 6/10",
		content:"You did okay, but you can definitely do better! It might be time to read the books again!",
		image:"http://i.giphy.com/cYYx0b3DcYwOA.gif",
		},
		];


		function GetURLParameter(sParam)
		{
		var sPageURL = window.location.search.substring(1);
		var sURLVariables = sPageURL.split('&');
		for (var i = 0; i < sURLVariables.length; i++)
		{
		var sParameterName = sURLVariables[i].split('=');
		if (sParameterName[0] == sParam)
		{
		return sParameterName[1];
		}
		}
		};

		var currentAnswerKey = GetURLParameter('custom_wpvqresults');

		var currentAnswerObjectArray = $.grep(result.quizOutputs , function(n, i) {
			return n.param.trim() == currentAnswerKey.trim() ;
			});
			if (currentAnswerObjectArray.length > 0) {
			var currentAnswerObject = currentAnswerObjectArray[0];
			// fill the form elements with answer
			$('.header').html(currentAnswerObject.header);
			$('.content').html(currentAnswerObject.content);
			$('.resultImage').attr("src",currentAnswerObject.image);
			}
			else
			{
			$('.header').text("sorry, we could not calculate your result:(");
			}

		$('.postScript').html(result.postScript);
		$('.freeGiftForm').attr('action', result.freeGiftLink);